=== BallBuster Music 21 ===
Contributors: Brandon LaDuke
Tested up to: 5.5
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This is the new incarnation of the BallBuster website evolution.

== Changelog ==

= 4.0.2 =
* Released: September 20, 2021

= 4.0.1 =
* Released: September 19, 2021

= 4.0 =
* Released: September 18, 2021


Initial release

== Copyright ==

BallBuster Music 2021

BallBuster Music 21 is derived from the Twenty Twenty,

BallBuster Music 21 bundles the following third-party resources:

Illustrations by Tammie Lister
License: Creative Commons Zero (CC0), https://creativecommons.org/publicdomain/zero/1.0/

Inter Font
Copyright (c) 2016-2019 The Inter Project Authors (me@rsms.me)
License: SIL Open Font License, 1.1, https://opensource.org/licenses/OFL-1.1
Source: https://rsms.me/inter/

Bespoke Icons Created For Twenty Twenty
License: Creative Commons Zero (CC0), https://creativecommons.org/publicdomain/zero/1.0/
List of bespoke icons:
- Search icon
- Menu icon

Feather Icons
Copyright (c) 2013-2017 Cole Bemis
License: MIT License, https://opensource.org/licenses/MIT
Source: https://feathericons.com
Used for post meta icons, and the link icon in the social menu.

TikTok Icon
License: GPLv2
Source: Émilie Lebrun - @Emlebrun
Used for TikTok social icon.

Social Icons
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Source: WordPress Social Link Block (See wp-includes\blocks\social-link.php)

Code from Twenty Nineteen
Copyright (c) 2018-2020 WordPress.org
License: GPLv2
Source: https://wordpress.org/themes/twentynineteen/
Included as part of the following classes and functions:
- TwentyTwenty_SVG_Icons
- twentytwenty_the_theme_svg()
- twentytwenty_get_theme_svg()
- twentytwenty_nav_menu_social_icons()

Code from Twenty Seventeen
Copyright (c) 2016-2020 WordPress.org
License: GPLv2
Source: https://wordpress.org/themes/twentyseventeen/
Included as part of the following classes and functions:
- twentytwenty_unique_id()

Underscores
https://underscores.me/, (C) 2012-2019 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
